#!/bin/bash

cd api && poetry install