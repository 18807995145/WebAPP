FILE_MODEL_IDENTITY = "__dify__file__"
