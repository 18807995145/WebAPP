class CredentialsValidateFailedError(ValueError):
    """
    Credentials validate failed error
    """

    pass
