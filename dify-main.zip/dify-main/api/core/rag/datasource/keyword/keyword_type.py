from enum import StrEnum


class KeyWordType(StrEnum):
    JIEBA = "jieba"
